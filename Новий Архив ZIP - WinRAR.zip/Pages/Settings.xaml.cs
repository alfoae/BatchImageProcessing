﻿using ImageProcessing.Models;
using ImageProcessing.Services;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Diagnostics.Metrics;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static ImageService;
using static System.Formats.Asn1.AsnWriter;
using MainWindow = ImageProcessing.MainWindow;

namespace ImageProcessing
{
    /// <summary>
    /// Логика взаимодействия для Settings.xaml
    /// </summary>
    public partial class Settings : Page
    {
        private bool _isDragging = false;
        private Point _clickPosition;
        private bool _isUpdatingUI = false;

        private ListBox _thumbnails;
        private bool _isInitializing = false;

        // Ім'я профілю водяних знаків прив'язане до кожного фото (шлях → назва профілю).
        private readonly Dictionary<string, string> _wmPhotoProfiles = new Dictionary<string, string>();


        public Settings(ListBox thumbnails)
        {
            _isInitializing = true;

            InitializeComponent();

            LoadProfiles();
            LoadWatermarkProfiles();

            for (int i = 1; i <= 4; i++)
            {
                streams.Items.Add(i);
            }
            

            streams.SelectedItem = Properties.Settings.Default.ThreadCount;

            streams.SelectedIndex = 0;

            SaveCurrentSettings();

            OneSize.IsChecked = ImageService.IsOneSizeOn;
            OneSize.Content = ImageService.IsOneSizeOn ? "ON" : "OFF";
            ComboWatermarkScope.SelectedIndex = ImageService.IsAllWatermarksMode ? 1 : 0;

            WatermarkPreviewImage.Source = ImageService.GetWatermarkBitmap();
            _thumbnails = thumbnails;
            ImageService.CurrentImageChanged += UpdatePreviewImage;
            ImageService.CurrentImageChanged += (bitmap) => 
            { 
                RefreshWatermarkComboBox();
                RenderPreviewWatermarks();
            };
            M1FolderEnter.Text = Properties.Settings.Default.LastSelectedPathEnter;
            M1FolderOut.Text = Properties.Settings.Default.LastSelectedPathOut;
            M2WatermarkPath.Text = Properties.Settings.Default.WatermarkFilePath;

            this.Loaded += (s, e) =>
            {
                LoadCurrentWatermarkToUI();
                RenderPreviewWatermarks();
            };

            ImageService.CurrentImageChanged += (bitmap) =>
            {
                LoadCurrentCropToUI();
            };

            ImageService.CurrentImageChanged += (bitmap) =>
            {
                string photoPath = ImageService.GetCurrentPhotoPath();

                if (ApplyToAllWatermark.IsChecked == true)
                {
                    // Режим "для всіх" — застосовуємо той самий профіль до нового фото
                    string? anyProfile = _wmPhotoProfiles.Values.FirstOrDefault();
                    if (anyProfile != null)
                    {
                        _wmPhotoProfiles[photoPath] = anyProfile;
                        ApplyWatermarkProfileByName(anyProfile);
                    }
                }

                // Відновлюємо комбобокс для цього фото
                _isUpdatingUI = true;
                if (!string.IsNullOrEmpty(photoPath) && _wmPhotoProfiles.TryGetValue(photoPath, out string? savedName))
                {
                    MyComboBoxN3Watermark.SelectedItem = savedName;
                    if (MyComboBoxN3Watermark.SelectedIndex < 0)
                        MyComboBoxN3Watermark.Text = savedName;
                }
                else
                {
                    MyComboBoxN3Watermark.SelectedIndex = -1;
                    MyComboBoxN3Watermark.Text = string.Empty;
                }
                _isUpdatingUI = false;
            };

            ImageService.WatermarkAlignmentChanged += () =>
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    RenderPreviewWatermarks(); // Виклик вашого методу рендерингу маленького прев'ю
                    UpdateCoordinateTextBoxes();
                }), System.Windows.Threading.DispatcherPriority.Render);
            };

            ImageService.CurrentCropChanged += (crop) =>
            {
                if (_isUpdatingUI) return;

                Dispatcher.BeginInvoke(new Action(() =>
                {
                    LoadCurrentCropToUI();
                }), System.Windows.Threading.DispatcherPriority.Render);
            };

            this.IsVisibleChanged += (s, e) =>
            {
                if (this.IsVisible)
                {
                    LoadCurrentCropToUI();
                }
            };

            if (ImageService.CurrentBitmap != null)
            {
                UpdatePreviewImage(ImageService.CurrentBitmap);
                LoadCurrentCropToUI();
            }

            ImageService.CurrentAlignmentChanged += () =>
            {
                UpdateAlignmentUIState();
            };

            this.IsVisibleChanged += (s, e) =>
            {
                if (this.IsVisible)
                {
                    LoadCurrentCropToUI();
                    UpdateAlignmentUIState(); // Оновлювати стан при відкритті вкладки
                }
            };

            if (ImageService.CurrentBitmap != null)
            {
                UpdatePreviewImage(ImageService.CurrentBitmap);
                LoadCurrentCropToUI();
                UpdateAlignmentUIState(); // Початкове налаштування стану
            }



            _isInitializing = false;


        }

        public void UpdatePermissions()
        {
            WatermarkToggle.IsEnabled = AuthService.CurrentUser?.Role == "Admin";
        }

        private void SquareBorder_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (!_isInitializing && ImageService.CurrentBitmap != null)
            {
                UpdatePreviewVisuals();
                RenderPreviewWatermarks();
            }
        }

        private void LoadCurrentCropToUI()
        {
            if (ImageService.CurrentCrop != Int32Rect.Empty)
            {
                _isInitializing = true;

                PosXBox.Text = ImageService.CurrentCrop.X.ToString();
                PosYBox.Text = ImageService.CurrentCrop.Y.ToString();
                WidthBox.Text = ImageService.CurrentCrop.Width.ToString();
                HeightBox.Text = ImageService.CurrentCrop.Height.ToString();

                _isInitializing = false;

                UpdatePreviewVisuals();
            }
        }

        // ВИПРАВЛЕННЯ: Цей метод тепер автоматично викликається при будь-якій зміні в полях
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!_isInitializing)
            {
                UpdatePreviewVisuals();
            }
        }

        public void UpdatePreviewImage(BitmapImage bitmap)
        {
            if (bitmap == null) return;

            SquareBorder.Background = new ImageBrush(bitmap)
            {
                Stretch = Stretch.Uniform,
                AlignmentX = AlignmentX.Center,
                AlignmentY = AlignmentY.Center
            };
        }

        private void SelectFolder_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button clickedButton)
            {
                if (sender is not TextBox clickedTextBox)
                {
                    throw new Exception("Щось пішло не так :/");
                }
                else
                {
                    string folder;
                    switch (clickedTextBox.Name)
                    {
                        case "M1FolderEnter":
                            folder = M1FolderEnter.Text;
                            break;
                        case "M1FolderOut":
                            folder = M1FolderOut.Text;
                            break;
                        case "M2WatermarkPath":
                            folder = M2WatermarkPath.Text;
                            break;
                        default: throw new Exception("Щось пішло не так :/");
                    }
                    string resrt = RedactorPageService.SelectFolder(sender, e, folder);
                    if (resrt == "reset")
                    {
                        M1FolderEnter.Text = Properties.Settings.Default.LastSelectedPathEnter;
                        M1FolderOut.Text = Properties.Settings.Default.LastSelectedPathOut;
                        M2WatermarkPath.Text = Properties.Settings.Default.WatermarkFilePath;
                    }

                    WatermarkPreviewImage.Source = ImageService.GetWatermarkBitmap();
                }
            }
            else
            {
                switch (clickedButton.Name)
                {
                    case "ButtonEnter":
                        M1FolderEnter.Text = RedactorPageService.SelectFolder(sender, e, string.Empty);
                        break;
                    case "ButtonOut":
                        M1FolderOut.Text = RedactorPageService.SelectFolder(sender, e, string.Empty);
                        break;
                    case "ButtonWatermarkBrowse":
                        M2WatermarkPath.Text = RedactorPageService.SelectFolder(sender, e, string.Empty);
                        break;
                    default: throw new Exception("Щось пішло не так :/");
                }
            }
        }

        private void UpdatePreviewVisuals()
        {
            if (ImageService.CurrentBitmap == null || SquareBorder.ActualWidth == 0 || PreviewRectangle == null) return;

            // Зчитуємо зміщення від центру та розміри з TextBox-ів
            if (!int.TryParse(PosXBox.Text, out int userX)) userX = 0;
            if (!int.TryParse(PosYBox.Text, out int userY)) userY = 0;
            if (!int.TryParse(WidthBox.Text, out int w)) w = 100;
            if (!int.TryParse(HeightBox.Text, out int h)) h = 100;

            // Обчислюємо коефіцієнт масштабування (ratio)
            double ratio = Math.Min(SquareBorder.ActualWidth / ImageService.CurrentBitmap.PixelWidth,
                                    SquareBorder.ActualHeight / ImageService.CurrentBitmap.PixelHeight);

            double renderedWidth = ImageService.CurrentBitmap.PixelWidth * ratio;
            double renderedHeight = ImageService.CurrentBitmap.PixelHeight * ratio;

            // Обчислюємо відступи картинки всередині SquareBorder (чорні смуги по боках/зверху)
            double offsetX = (SquareBorder.ActualWidth - renderedWidth) / 2;
            double offsetY = (SquareBorder.ActualHeight - renderedHeight) / 2;

            // Розмір прямокутника на екрані з урахуванням масштабу
            PreviewRectangle.Width = w * ratio;
            PreviewRectangle.Height = h * ratio;

            double finalLeft = (ImageService.CurrentBitmap.PixelWidth / 2.0 + userX) * ratio + offsetX - (PreviewRectangle.Width / 2.0);
            double finalTop = (ImageService.CurrentBitmap.PixelHeight / 2.0 + userY) * ratio + offsetY - (PreviewRectangle.Height / 2.0);

            // Встановлюємо координати для PreviewRectangle на Canvas
            Canvas.SetLeft(PreviewRectangle, finalLeft);
            Canvas.SetTop(PreviewRectangle, finalTop);




            // Оновлюємо дані кропу в сервісі
            if (!_isInitializing)
            {
                _isUpdatingUI = true;
                ImageService.CurrentCrop = new Int32Rect(userX, userY, w, h);
                _isUpdatingUI = false;
            }
        }

        private void TextBoxes_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (sender is TextBox textBox)
            {
                string cleanText = textBox.Text;

                if (textBox.Name == "WidthBox" || textBox.Name == "HeightBox")
                {
                    cleanText = System.Text.RegularExpressions.Regex.Replace(textBox.Text, "[^0-9]", "");
                }
                else if (textBox.Name == "PosXBox" || textBox.Name == "PosYBox")
                {
                    cleanText = System.Text.RegularExpressions.Regex.Replace(textBox.Text, "[^0-9-]", "");

                    if (cleanText.Contains("-"))
                    {
                        cleanText = "-" + cleanText.Replace("-", "");
                        if (cleanText == "-") return;
                    }
                }
                if (textBox.Text != cleanText)
                {
                    int caret = textBox.CaretIndex;
                    textBox.Text = cleanText;
                    textBox.CaretIndex = caret > 0 ? caret - 1 : 0;
                    return;
                }
            }
            if (sender is TextBox tb && tb.Text != "-" && tb.Text != "")
            {
                UpdatePreviewVisuals();
            }
        }

        private void PreviewCanvas_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            UpdatePreviewVisuals();
        }

        private void AdjustValue_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag != null)
            {
                string[] parts = btn.Tag.ToString().Split('_');
                if (parts.Length == 2)
                {
                    string targetBoxName = parts[0];
                    string action = parts[1];

                    // ЗАХИСТ: Перевірка блокування кнопок-стрілочок при увімкненому вирівнюванні
                    if (ImageService.IsCurrentAlignmentEnabled)
                    {
                        int alignType = int.Parse(ImageService.CurrentAlignmentType);

                        if (alignType == 0 && (targetBoxName == "PosXBox" || targetBoxName == "PosYBox"))
                            return; // Центр — блокуємо і X, і Y

                        if (alignType == 1 && targetBoxName == "PosXBox")
                            return; // По висоті — блокуємо X

                        if (alignType == 2 && targetBoxName == "PosYBox")
                            return; // По ширині — блокуємо Y
                    }

                    TextBox targetBox = null;
                    if (targetBoxName == "HeightBox") targetBox = HeightBox;
                    else if (targetBoxName == "WidthBox") targetBox = WidthBox;
                    else if (targetBoxName == "PosXBox") targetBox = PosXBox;
                    else if (targetBoxName == "PosYBox") targetBox = PosYBox;

                    string textValue = (targetBox != null && targetBox.Text == "-") ? "0" : targetBox?.Text;

                    if (targetBox != null && int.TryParse(textValue, out int currentValue))
                    {
                        if (action == "Up")
                        {
                            // Тепер просто додаємо +1 для всіх кнопок "Вгору"
                            currentValue++;
                        }
                        else if (action == "Down")
                        {
                            // Захист ширини і висоти
                            if ((targetBoxName == "WidthBox" || targetBoxName == "HeightBox") && currentValue <= 1)
                                return;

                            // Віднімаємо -1 для всіх кнопок "Вниз"
                            currentValue--;
                        }

                        targetBox.Text = currentValue.ToString();
                    }
                }
            }
        }
        private void MyComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (MyComboBox != null && MyComboBox.SelectedItem is ComboBoxItem item)
            {
                ImageService.SelectedQuality = item.Content?.ToString() ?? "1080p";
            }
        }

        private void MyComboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (MyComboBox1 != null && MyComboBox1.SelectedItem is ComboBoxItem item)
            {
                ImageService.SelectedFormat = item.Content?.ToString() ?? "PNG";
            }
        }

        private void SaveCurrentSettings()
        {
            ImageService.SelectedQuality = (MyComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "1080p";
            ImageService.SelectedFormat = (MyComboBox1.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "PNG";
        }

        private void GlobalSizeSwitch_Click(object sender, RoutedEventArgs e)
        {
            if (GlobalSizeSwitch.IsChecked == true)
            {
                if (ImageService.CurrentCrop != Int32Rect.Empty)
                {
                    ImageService.GlobalWidth = ImageService.CurrentCrop.Width;
                    ImageService.GlobalHeight = ImageService.CurrentCrop.Height;
                }

                ImageService.IsGlobalCropSize = true;
                GlobalSizeSwitch.Content = "ON";
            }
            else
            {
                ImageService.IsGlobalCropSize = false;
                GlobalSizeSwitch.Content = "OFF";

                ImageService.CopyGlobalSizeToAllImages();
            }

            _isInitializing = true;
            _isInitializing = false;

            UpdatePreviewVisuals();
        }

        

        private void AlignmentSwitch_Click(object sender, RoutedEventArgs e)
        {
            if (_isUpdatingUI) return;

            ImageService.IsCropAlignmentOn = AlignmentSwitch.IsChecked == true;
            AlignmentSwitch.Content = ImageService.IsCropAlignmentOn ? "ON" : "OFF";
            AlignmentComboBox.IsEnabled = ImageService.IsCropAlignmentOn;

            if (ImageService.IsCropAlignmentOn)
            {
                ImageService.RecalculateCropAlignment();
            }
        }

        private void WMAlignmentComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_isInitializing || _isUpdatingUI) return;
            if (MyComboBoxN1 == null || WMAlignmentComboBox == null) return;

            var layers = ImageService.GetCurrentPhotoLayers();
            int selectedIndex = MyComboBoxN1.SelectedIndex;
            if (layers == null || selectedIndex == -1 || selectedIndex >= layers.Count) return;

            var activeLayer = layers[selectedIndex];

            // 1. Записуємо новий індекс вирівнювання у вибраний шар
            activeLayer.AlignmentIndex = WMAlignmentComboBox.SelectedIndex;

            // 2. ПЕРЕВІРКА: Якщо знак глобальний ТА увімкнена кнопка "Синхронізувати однаковий ID"
            if (activeLayer.IsGlobal && ToggleSameIdAlignment.IsChecked == true)
            {
                // Змінюємо вирівнювання на ВСІХ фотографіях (твоя поточна логіка синхронізації)
                SyncGlobalAlignmentSettings(activeLayer);
            }
            else
            {
                // Інакше (локальний знак АБО глобальний, але кнопка OFF) — 
                // застосовуємо зміни ТІЛЬКИ для поточної фотографії
                ImageService.ApplyWatermarkAlignment(activeLayer, isDragging: false);
            }

            // 3. Сповіщаємо головний редактор (велике фото)
            ImageService.NotifyWatermarksChanged();

            // 4. Оновлюємо міні-прев'ю (блакитний квадрат) на сторінці налаштувань
            RenderPreviewWatermarks();
        }

        private void UpdateAlignmentUIState()
{
    if (AlignmentSwitch == null || AlignmentComboBox == null) return;

    // Зчитуємо саме стан вирівнювання нашої рамки обрізки
    bool isEnabled = ImageService.IsCropAlignmentOn;
    int selectedIndex = ImageService.CropAlignmentIndex;

    bool previouslyUpdating = _isUpdatingUI;
    _isUpdatingUI = true; // Тимчасово блокуємо івенти, щоб уникнути зациклення

    AlignmentSwitch.IsChecked = isEnabled;
    AlignmentSwitch.Content = isEnabled ? "ON" : "OFF";
    AlignmentComboBox.IsEnabled = isEnabled;
    AlignmentComboBox.SelectedIndex = selectedIndex;

    _isUpdatingUI = previouslyUpdating;
}
        


        private void GoBack_Click(object sender, RoutedEventArgs e)
        {
            if (_isInitializing || _isUpdatingUI) return;

            ImageService.SelectPreviousImage();

            if (ImageService._thumbnailList != null)
            {
                ImageService._thumbnailList.SelectedIndex = ImageService.CurrentIndex;
            }
        }

        private void GoForward_Click(object sender, RoutedEventArgs e)
        {
            if (_isInitializing || _isUpdatingUI) return;

            ImageService.SelectNextImage();

            if (ImageService._thumbnailList != null)
            {
                ImageService._thumbnailList.SelectedIndex = ImageService.CurrentIndex;
            }
        }


        private void CropAlignmentComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_isUpdatingUI || _isInitializing || AlignmentComboBox == null) return;

            ImageService.CropAlignmentIndex = AlignmentComboBox.SelectedIndex;

            if (ImageService.IsCropAlignmentOn)
            {
                ImageService.RecalculateCropAlignment();
            }
        }

        private void OneAlignmentCheck_Click(object sender, RoutedEventArgs e)
        {
            if (OneAlignmentCheck.IsChecked == true)
            {
                if (ImageService.CurrentCrop != Int32Rect.Empty)
                {
                    ImageService.GlobalX = ImageService.CurrentCrop.X;
                    ImageService.GlobalY = ImageService.CurrentCrop.Y;
                }

                ImageService.IsGlobalCropPosition = true;
                OneAlignmentCheck.Content = "ON";
            }
            else
            {
                ImageService.IsGlobalCropPosition = false;
                OneAlignmentCheck.Content = "OFF";

                ImageService.CopyGlobalPositionToAllImages();
            }

            _isInitializing = true;
            _isInitializing = false;

            UpdatePreviewVisuals();
        }

        private void ApplyToAll_Checked(object sender, RoutedEventArgs e)
        {
            ApplyToAll.Content = "Для всіх полів";
        }

        private void ApplyToAll_Unchecked(object sender, RoutedEventArgs e)
        {
            ApplyToAll.Content = "Для цього поля";
        }

        private void LoadProfiles()
        {
            MyComboBoxN3.Items.Clear();

            foreach (var profile in ProfileService.Profiles)
            {
                MyComboBoxN3.Items.Add(profile.Name);
            }
        }

        private void SaveProfile_Click(object sender, RoutedEventArgs e)
        {
            string profileName = MyComboBoxN3.Text;

            if (string.IsNullOrWhiteSpace(profileName))
            {
                MessageBox.Show("Введіть назву профілю");
                return;
            }

            var existing = ProfileService.Profiles
                .FirstOrDefault(x => x.Name == profileName);

            if (existing != null)
            {
                ProfileService.Profiles.Remove(existing);
            }

            Int32Rect crop = ImageService.CurrentCrop;

            var profile = new ProcessingProfile
            {
                Name = profileName,

                CropX = crop.X,
                CropY = crop.Y,
                CropWidth = crop.Width,
                CropHeight = crop.Height,

                ApplyToAll = ApplyToAll.IsChecked == true
            };

            ProfileService.Profiles.Add(profile);

            ProfileService.Save();

            LoadProfiles();

            MessageBox.Show("Профіль збережено");
        }

        private void MyComboBoxN3_SelectionChanged(
    object sender,
    SelectionChangedEventArgs e)
        {
            if (MyComboBoxN3.SelectedItem == null)
                return;

            string selected = MyComboBoxN3.SelectedItem.ToString();

            var profile = ProfileService.Profiles
                .FirstOrDefault(x => x.Name == selected);

            if (profile == null)
                return;

            ImageService.CurrentCrop = new Int32Rect(
                profile.CropX,
                profile.CropY,
                profile.CropWidth,
                profile.CropHeight);

            ApplyToAll.IsChecked = profile.ApplyToAll;

            MessageBox.Show("Профіль завантажено");
        }

        private void DeleteProfile_Click(object sender, RoutedEventArgs e)
        {
            if (MyComboBoxN3.SelectedItem == null)
                return;

            string selected = MyComboBoxN3.SelectedItem.ToString();

            var profile = ProfileService.Profiles
                .FirstOrDefault(x => x.Name == selected);

            if (profile == null)
                return;

            ProfileService.Profiles.Remove(profile);

            ProfileService.Save();

            LoadProfiles();

            MyComboBoxN3.Text = "";

            MessageBox.Show("Профіль видалено");
        }

        //ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ
        //ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ
        //ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ
        //ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ
        //ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ
        //ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ
        //ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ ДРУГА ПАНЕЛЬКА ДЛЯ ВОДЯНОГО ЗНАКУ

        private void WatermarkBack_Click(object sender, RoutedEventArgs e)
        {
            if (_isInitializing || _isUpdatingUI) return;
            WatermarkPreviewImage.Source = ImageService.GetNextWatermarkBitmap(-1);
        }

        private void WatermarkForward_Click(object sender, RoutedEventArgs e)
        {
            if (_isInitializing || _isUpdatingUI) return;
            WatermarkPreviewImage.Source = ImageService.GetNextWatermarkBitmap(1);
        }

        private void WatermarkToggle_Click(object sender, RoutedEventArgs e)
        {
            if (WatermarkToggle.IsChecked == true)
                WatermarkToggle.Content = "ON";
            else
                WatermarkToggle.Content = "OFF";
        }

        private void ButtonAddWatermark_Click(object sender, RoutedEventArgs e)
        {
            // 1. Спочатку перевіряємо ініціалізацію сторінки (без перевірки _isUpdatingUI!)
            if (_isInitializing) return;

            // 2. Вмикаємо захист інтерфейсу від фантомних спрацьовувань подій
            _isUpdatingUI = true;

            try
            {
                string currentPath = Properties.Settings.Default.WatermarkFilePath;
                if (string.IsNullOrEmpty(currentPath) || !System.IO.File.Exists(currentPath))
                {
                    MessageBox.Show("Будь ласка, спочатку оберіть або завантажте файл водяного знаку.");
                    return;
                }

                // Створюємо новий шар у сервісі
                var newLayer = ImageService.AddNewWatermark(currentPath);

                // 3. ПРИМУСОВО скидаємо тумблер у OFF, бо новий знак завжди локальний
                if (ToggleGlobalWatermark != null)
                {
                    ToggleGlobalWatermark.IsChecked = false;
                    ToggleGlobalWatermark.Content = "OFF";
                }

                // 4. Перестворюємо елементи ComboBox, щоб підтягнути нові дані
                RefreshWatermarkComboBox();

                // 5. Вибираємо щойно створений водяний знак за його актуальним індексом
                var layers = ImageService.GetCurrentPhotoLayers();
                if (layers != null)
                {
                    int targetIndex = layers.FindIndex(l => l.Id == newLayer.Id);
                    if (targetIndex >= 0)
                    {
                        MyComboBoxN1.SelectedIndex = targetIndex;
                    }
                }
            }
            finally
            {
                // 6. Гарантовано знімаємо захист інтерфейсу
                _isUpdatingUI = false;
            }

            // Після виходу з try-finally викликаємо синхронізацію та перемальовування
            SyncUIWithSelectedWatermark();
            UpdateWatermarkUIFromSelection();
            RenderPreviewWatermarks();
        }

        private void MyComboBoxN1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_isInitializing || _isUpdatingUI) return;

            // Просто викликаємо централізовану синхронізацію
            SyncUIWithSelectedWatermark();
            UpdateWatermarkUIFromSelection();
        }

        private void ButtonRemoveWatermark_Click(object sender, RoutedEventArgs e)
        {
            if (_isInitializing || _isUpdatingUI) return;

            int selectedIndex = MyComboBoxN1.SelectedIndex;
            var layers = ImageService.GetCurrentPhotoLayers();

            if (selectedIndex == -1 || selectedIndex >= layers.Count) return;

            // Отримуємо дані саме того знака, який користувач хоче видалити
            var activeLayer = layers[selectedIndex];
            int targetId = activeLayer.Id;
            bool isGlobal = activeLayer.IsGlobal;
            string targetOriginalPath = activeLayer.OriginalPhotoPath;
            string currentPhotoPath = ImageService.GetCurrentPhotoPath();

            // 1. Видаляємо водяний знак з поточної фотографії
            layers.RemoveAt(selectedIndex);

            // 2. Якщо цей конкретний знак був глобальним, видаляємо його копії з усіх інших фотографій
            if (isGlobal)
            {
                var allPhotos = ImageService.GetAllImageFiles();
                if (allPhotos != null)
                {
                    foreach (var photoPath in allPhotos)
                    {
                        // Поточну світлину пропускаємо, бо з неї вже видалили вище
                        if (photoPath == currentPhotoPath) continue;

                        if (ImageService.ImageWatermarks.TryGetValue(photoPath, out var targetLayers))
                        {
                            // Шукаємо точну копію: збігається Id, знак є глобальним і має той самий OriginalPhotoPath
                            var copy = targetLayers.FirstOrDefault(l =>
                                l.Id == targetId &&
                                l.IsGlobal &&
                                l.OriginalPhotoPath == targetOriginalPath);

                            if (copy != null)
                            {
                                targetLayers.Remove(copy);
                            }

                            // Обов'язково пересортовуємо список шарів для цієї фотографії
                            SortAndReorderLayers(targetLayers);
                        }
                    }
                }
            }

            // 3. Оновлюємо комбобокс та прев'ю на екрані
            RefreshWatermarkComboBox();
            RenderPreviewWatermarks();
        }

        private void RefreshWatermarkComboBox()
        {
            bool prevUpdating = _isUpdatingUI;
            _isUpdatingUI = true;

            int savedSelectedIndex = MyComboBoxN1.SelectedIndex;
            MyComboBoxN1.Items.Clear();

            var layers = ImageService.GetCurrentPhotoLayers();

            if (layers != null)
            {
                for (int i = 0; i < layers.Count; i++)
                {
                    // Виводимо ID безпосередньо у назву — завдяки алгоритму пропусків 
                    // номери будуть ідеально відображати реальну картину
                    MyComboBoxN1.Items.Add(
                        new ComboBoxItem { Content = $"Водяний знак №{layers[i].Id}" });
                }

                if (savedSelectedIndex >= 0 && savedSelectedIndex < layers.Count)
                    MyComboBoxN1.SelectedIndex = savedSelectedIndex;
                else if (MyComboBoxN1.Items.Count > 0)
                    MyComboBoxN1.SelectedIndex = 0;
                else
                    MyComboBoxN1.SelectedIndex = -1;
            }

            _isUpdatingUI = prevUpdating;
            SyncUIWithSelectedWatermark();
            UpdateWatermarkUIFromSelection();
        }

        private void RenderPreviewWatermarks()
        {
            var imagesToRemove = PreviewCanvas.Children.OfType<Image>().ToList();
            foreach (var img in imagesToRemove)
            {
                PreviewCanvas.Children.Remove(img);
            }

            if (ImageService.CurrentBitmap == null) return;

            if (PreviewRectangle != null)
            {
                Panel.SetZIndex(PreviewRectangle, 999);
            }

            if (SquareBorder.ActualWidth == 0 || SquareBorder.ActualHeight == 0) return;

            double scaleX = SquareBorder.ActualWidth / ImageService.CurrentBitmap.PixelWidth;
            double scaleY = SquareBorder.ActualHeight / ImageService.CurrentBitmap.PixelHeight;
            double uniformScale = Math.Min(scaleX, scaleY);

            double centerX = SquareBorder.ActualWidth / 2.0;
            double centerY = SquareBorder.ActualHeight / 2.0;

            ImageService.PreviewScale = uniformScale;
            ImageService.PreviewCenterX = centerX;
            ImageService.PreviewCenterY = centerY;

            foreach (var layer in ImageService.GetCurrentPhotoLayers())
            {
                double screenW = layer.Width * uniformScale;
                double screenH = layer.Height * uniformScale;

                Image wmImage = new Image
                {
                    Source = new BitmapImage(
                        new Uri(layer.ImagePath, UriKind.RelativeOrAbsolute)
                    ),
                    Width = screenW,
                    Height = screenH,
                    Stretch = Stretch.Fill,
                    IsHitTestVisible = false,

                    // === ОСЬ ЦЕЙ РЯДОК ВСЕ ВИПРАВЛЯЄ ===
                    // Застосовуємо прозорість із моделі даних водяного знака
                    Opacity = layer.Opacity
                };

                // Та сама система координат що і в Redactor (GetScreenRect):
                // (0,0) = центр зображення = центр канвасу
                // screenPos = canvasCenter + (modelOffset * scale) - (elementSize / 2)
                double screenX = centerX + (layer.X * uniformScale) - (screenW / 2.0);
                double screenY = centerY + (layer.Y * uniformScale) - (screenH / 2.0);

                Canvas.SetLeft(wmImage, screenX);
                Canvas.SetTop(wmImage, screenY);

                PreviewCanvas.Children.Add(wmImage);
            }
        }

        private void ToggleGlobalWatermark_Checked(object sender, RoutedEventArgs e)
        {
            if (_isUpdatingUI) return;

            var currentLayers = ImageService.GetCurrentPhotoLayers();
            int selectedIndex = MyComboBoxN1.SelectedIndex;

            if (currentLayers != null && selectedIndex >= 0 && selectedIndex < currentLayers.Count)
            {
                var activeLayer = currentLayers[selectedIndex];

                // 1. Налаштовуємо черговість для батьківського знака
                activeLayer.IsGlobal = true;
                activeLayer.GlobalOrder++;

                int targetId = activeLayer.Id;
                string currentPhotoPath = ImageService.GetCurrentPhotoPath();
                var allPhotos = ImageService.GetAllImageFiles();

                // 2. Розмножуємо по інших фотографіях з ТИМ САМИМ ID
                if (allPhotos != null && !string.IsNullOrEmpty(currentPhotoPath))
                {
                    foreach (var photoPath in allPhotos)
                    {
                        if (photoPath == currentPhotoPath)
                            continue;

                        if (!ImageService.ImageWatermarks.TryGetValue(photoPath, out var targetLayers))
                        {
                            targetLayers = new List<ImageService.WatermarkLayer>();
                            ImageService.ImageWatermarks[photoPath] = targetLayers;
                        }

                        // Якщо на іншому фото цей ID уже зайнятий —
                        // посуваємо існуючий знак на перший вільний номер
                        var conflictingLocal = targetLayers.FirstOrDefault(l => l.Id == targetId);

                        if (conflictingLocal != null)
                        {
                            conflictingLocal.Id = GenerateNextAvailableLocalId(targetLayers);
                        }

                        // Створюємо глобальну копію
                        var clonedLayer = new ImageService.WatermarkLayer
                        {
                            Id = targetId,
                            ImagePath = activeLayer.ImagePath,
                            X = activeLayer.X,
                            Y = activeLayer.Y,
                            Width = activeLayer.Width,
                            Height = activeLayer.Height,
                            Opacity = activeLayer.Opacity,
                            OriginalPhotoPath = activeLayer.OriginalPhotoPath,
                            IsGlobal = true,
                            GlobalOrder = activeLayer.GlobalOrder,
                            IsAlignmentEnabled = activeLayer.IsAlignmentEnabled,
                            SelectedAlignment = activeLayer.SelectedAlignment,
                            UseAlignment = activeLayer.UseAlignment,
                            AlignmentIndex = activeLayer.AlignmentIndex
                        };

                        targetLayers.Add(clonedLayer);

                        SortAndReorderLayers(targetLayers);
                    }
                }

                // 3. Сортуємо та оновлюємо UI
                SortAndReorderLayers(currentLayers);
                RefreshWatermarkComboBox();

                // Повертаємо фокус на переміщений елемент
                int newIndex = currentLayers.FindIndex(l => l.Id == targetId);
                if (newIndex >= 0) MyComboBoxN1.SelectedIndex = newIndex;
            }
        }

        private void ToggleGlobalWatermark_Unchecked(object sender, RoutedEventArgs e)
        {
            if (_isUpdatingUI) return;

            var currentLayers = ImageService.GetCurrentPhotoLayers();
            int selectedIndex = MyComboBoxN1.SelectedIndex;

            if (currentLayers != null && selectedIndex >= 0 && selectedIndex < currentLayers.Count)
            {
                var activeLayer = currentLayers[selectedIndex];
                int oldGlobalId = activeLayer.Id;
                string currentPhotoPath = ImageService.GetCurrentPhotoPath();
                var allPhotos = ImageService.GetAllImageFiles();

                // 1. Видаляємо копії з інших фотографій
                if (allPhotos != null)
                {
                    foreach (var photoPath in allPhotos)
                    {
                        if (photoPath == currentPhotoPath) continue;

                        if (ImageService.ImageWatermarks.TryGetValue(photoPath, out var targetLayers))
                        {
                            var copy = targetLayers.FirstOrDefault(l => l.Id == oldGlobalId);
                            if (copy != null && copy.OriginalPhotoPath == currentPhotoPath)
                            {
                                targetLayers.Remove(copy);
                            }
                            SortAndReorderLayers(targetLayers);
                        }
                    }
                }

                // 2. Робимо батьківський знак знову локальним
                activeLayer.IsGlobal = false;
                activeLayer.GlobalOrder = 0;

                // Присвоюємо йому перший вільний локальний ID на цій картінці (з урахуванням пропусків)
                activeLayer.Id = GenerateNextAvailableLocalId(currentLayers);

                // 3. Пересортовуємо і оновлюємо відображення
                SortAndReorderLayers(currentLayers);
                RefreshWatermarkComboBox();

                int newIndex = currentLayers.FindIndex(l => l.Id == activeLayer.Id);
                if (newIndex >= 0) MyComboBoxN1.SelectedIndex = newIndex;
            }
        }

        private void UpdateToggleApplyModeAvailability()
        {
            // Якщо йде ініціалізація або ми вже оновлюємо UI — виходимо, щоб не зациклювати!
            if (ToggleGlobalWatermark == null || ComboWatermarkScope == null || OneSize == null || _isUpdatingUI || _isInitializing) return;

            // Зчитуємо поточні стани
            bool isGlobalOn = ToggleGlobalWatermark.IsChecked == true;
            bool isAllWatermarksSelected = ComboWatermarkScope.SelectedIndex == 1; // "Всіх № водяних знаків"
            bool isThisWatermarkSelected = ComboWatermarkScope.SelectedIndex == 0; // "Цього № водяного знаку"

            // Перевіряємо головну умову доступності кнопки OneSize
            if (isAllWatermarksSelected || (isThisWatermarkSelected && isGlobalOn))
            {
                OneSize.IsEnabled = true; // Кнопка стає активною
            }
            else
            {
                // Вмикаємо захист від зациклення подій
                _isUpdatingUI = true;

                OneSize.IsChecked = false;
                OneSize.Content = "OFF";
                OneSize.IsEnabled = false; // Засірюємо кнопку

                _isUpdatingUI = false;
            }
        }

        private void ComboWatermarkScope_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboWatermarkScope == null) return;
            if (_isUpdatingUI || _isInitializing) return;

            UpdateToggleApplyModeAvailability();
            ImageService.IsAllWatermarksMode = ComboWatermarkScope.SelectedIndex == 1;

            if (OneSize != null && OneSize.IsChecked == true)
            {
                SyncWatermarkSizes();
                UpdateToggleApplyModeAvailability();
            }
        }
        private void OneSize_Click(object sender, RoutedEventArgs e)
        {
            ImageService.IsOneSizeOn = OneSize.IsChecked == true;
            OneSize.Content = ImageService.IsOneSizeOn ? "ON" : "OFF";

            if (_isUpdatingUI || _isInitializing) return;

            if (OneSize.IsChecked == true)
            {
                OneSize.Content = "ON";
                SyncWatermarkSizes();
            }
            else
            {
                OneSize.Content = "OFF";
            }
        }

        private void SyncWatermarkSizes()
        {
            // Якщо кнопка OneSize не затиснута (OFF) або UI оновлюється — нічого не робимо
            if (OneSize.IsChecked != true || _isUpdatingUI || _isInitializing) return;

            var currentLayers = ImageService.GetCurrentPhotoLayers();
            int selectedIndex = MyComboBoxN1.SelectedIndex;

            // Перевіряємо, чи є взагалі вибраний знак
            if (selectedIndex == -1 || selectedIndex >= currentLayers.Count) return;

            // Беремо еталонний знак, чий розмір будемо копіювати
            var baseLayer = currentLayers[selectedIndex];
            double targetWidth = baseLayer.Width;
            double targetHeight = baseLayer.Height;

            var allPhotos = ImageService.GetAllImageFiles();
            bool isAllWatermarksMode = ComboWatermarkScope.SelectedIndex == 1; // True, якщо "Всіх № водяних знаків"

            // Тимчасово блокуємо UI, щоб не зациклити виклики подій
            _isUpdatingUI = true;

            foreach (var photoPath in allPhotos)
            {
                if (!ImageService.ImageWatermarks.TryGetValue(photoPath, out var targetLayers)) continue;

                foreach (var layer in targetLayers)
                {
                    if (isAllWatermarksMode)
                    {
                        // Режим 1: Змінюємо розмір ВЗАГАЛІ ВСІХ знаків на ВСІХ фото
                        layer.Width = targetWidth;
                        layer.Height = targetHeight;
                    }
                    else
                    {
                        // Режим 2: Змінюємо розмір тільки знаків з таким самим ID (наприклад, тільки для №7)
                        if (layer.Id == baseLayer.Id)
                        {
                            layer.Width = targetWidth;
                            layer.Height = targetHeight;
                        }
                    }
                }
            }

            _isUpdatingUI = false;

            // Оновлюємо прев'юшку на екрані, щоб одразу побачити результат
            RenderPreviewWatermarks();
        }

        public void LoadCurrentWatermarkToUI()
        {
            if (_isUpdatingUI || _isInitializing || MyComboBoxN1 == null || WmWidthBox == null || WmHeightBox == null) return;

            var layers = ImageService.GetCurrentPhotoLayers();
            int selectedIndex = MyComboBoxN1.SelectedIndex;

            if (selectedIndex != -1 && selectedIndex < layers.Count)
            {
                var activeLayer = layers[selectedIndex];

                _isInitializing = true;
                WmWidthBox.Text = ((int)activeLayer.Width).ToString();
                WmHeightBox.Text = ((int)activeLayer.Height).ToString();

                WmXBox.Text = ((int)activeLayer.X).ToString();
                WmYBox.Text = ((int)activeLayer.Y).ToString();
                _isInitializing = false;
            }
        }

        // 2. Обробник ручного введення тексту (цифр) в поля ширини/висоти знака
        private void WmTextBoxes_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_isUpdatingUI || _isInitializing) return;

            if (sender is TextBox textBox)
            {
                // Дозволяємо лише цифри
                string cleanText = System.Text.RegularExpressions.Regex.Replace(textBox.Text, "[^0-9]", "");
                if (textBox.Text != cleanText)
                {
                    int caret = textBox.CaretIndex;
                    textBox.Text = cleanText;
                    textBox.CaretIndex = caret > 0 ? caret - 1 : 0;
                    return;
                }

                if (string.IsNullOrEmpty(cleanText) || cleanText == "0") return;

                if (int.TryParse(cleanText, out int val))
                {
                    var layers = ImageService.GetCurrentPhotoLayers();
                    int selectedIndex = MyComboBoxN1.SelectedIndex;

                    if (selectedIndex != -1 && selectedIndex < layers.Count)
                    {
                        var activeLayer = layers[selectedIndex];

                        if (textBox.Name == "WmWidthBox") activeLayer.Width = val;
                        if (textBox.Name == "WmHeightBox") activeLayer.Height = val;



                        // Запускаємо твою динамічну синхронізацію (якщо OneSize увімкнено)
                        SyncWatermarkSizes();

                        if (ImageService.IsWatermarkAlignmentEnabled)
                        {
                            ImageService.UpdateAndTriggerAlignment();
                        }
                        // Оновлюємо картинку на екрані
                        RenderPreviewWatermarks();
                    }
                }
            }
        }

        // 3. Обробник натискання на стрілочки вгору/вниз для водяного знака
        private void AdjustWmValue_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag != null)
            {
                string[] parts = btn.Tag.ToString().Split('_');
                if (parts.Length == 2)
                {
                    string targetBoxName = parts[0];
                    string action = parts[1];

                    TextBox targetBox = null;
                    if (targetBoxName == "WmHeightBox") targetBox = WmHeightBox;
                    else if (targetBoxName == "WmWidthBox") targetBox = WmWidthBox;
                    else if (targetBoxName == "WmXBox") targetBox = WmXBox;
                    else if (targetBoxName == "WmYBox") targetBox = WmYBox;

                    if (targetBox != null && int.TryParse(targetBox.Text, out int currentValue))
                    {
                        if (action == "Up")
                        {
                            currentValue++;
                        }
                        else if (action == "Down")
                        {
                            if ((targetBoxName == "WmHeightBox" || targetBoxName == "WmWidthBox") && currentValue <= 5)
                                return;

                            currentValue--;
                        }

                        targetBox.Text = currentValue.ToString();
                    }
                }
            }
        }

        private void WmPos_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_isUpdatingUI || _isInitializing) return;

            // === ФІКС 1: Якщо вирівнювання УКВІМКНЕНО, не даємо користувачу змінювати X та Y вручну ===
            if (ImageService.IsWatermarkAlignmentEnabled)
            {
                // Просто оновлюємо текстові поля назад до зафіксованих системою значень
                UpdateCoordinateTextBoxes();
                return;
            }

            var layers = ImageService.GetCurrentPhotoLayers();
            if (layers == null || MyComboBoxN1.SelectedIndex < 0 || MyComboBoxN1.SelectedIndex >= layers.Count)
                return;

            var layer = layers[MyComboBoxN1.SelectedIndex];

            bool parsedX = double.TryParse(WmXBox.Text, out double x);
            bool parsedY = double.TryParse(WmYBox.Text, out double y);

            if (parsedX && parsedY)
            {
                layer.X = x;
                layer.Y = y;

                if (ImageService.IsSameIdAlignmentOn)
                {
                    ImageService.SyncWatermarkPositions(layer);
                }

                RenderPreviewWatermarks();
            }
        }
        private void OnlyNumbers_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Дозволяємо цифри від 0 до 9 і знак мінуса для від'ємних координат
            bool isNumber = System.Text.RegularExpressions.Regex.IsMatch(e.Text, "[0-9.-]");
            e.Handled = !isNumber;
        }

        private void ToggleSameIdAlignment_Checked(object sender, RoutedEventArgs e)
        {
            if (_isInitializing || _isUpdatingUI) return;

            // 1. Одразу міняємо текст кнопки на ON
            ToggleSameIdAlignment.Content = "ON";

            // 2. Беремо поточний вибраний водяний знак (наш донор координат)
            var layers = ImageService.GetCurrentPhotoLayers();
            int selectedIndex = MyComboBoxN1.SelectedIndex;
            if (layers == null || selectedIndex == -1 || selectedIndex >= layers.Count) return;

            var activeLayer = layers[selectedIndex];

            // Копіюємо тільки якщо знак глобальний
            if (!activeLayer.IsGlobal) return;

            // Отримуємо шлях до поточної фотографії прямо з нашого активного шару
            string currentFile = activeLayer.OriginalPhotoPath;

            // Запам'ятовуємо точні координати на даний момент
            double sourceX = activeLayer.X;
            double sourceY = activeLayer.Y;

            // 3. Пробігаємося по ВСІХ фотографіях у програмі та копіюємо чисті координати
            foreach (var photoPath in ImageService.ImageWatermarks.Keys)
            {
                // Поточну фотографію пропускаємо, на ній знак уже стоїть де треба
                if (photoPath == currentFile) continue;

                // Шукаємо на іншій фотографії знак з таким самим GlobalOrder
                var sameLayer = ImageService.ImageWatermarks[photoPath]
                    .FirstOrDefault(l => l.IsGlobal && l.GlobalOrder == activeLayer.GlobalOrder);

                if (sameLayer != null)
                {
                    // Напряму вставляємо координати
                    sameLayer.X = sourceX;
                    sameLayer.Y = sourceY;

                    // Запускаємо базовий захист, щоб знак не вилетів за межі, якщо фото іншого розміру
                    ImageService.ApplyWatermarkAlignment(sameLayer, isDragging: false, photoPath: photoPath);
                }
            }

            // 4. Оновлюємо екрани
            ImageService.NotifyWatermarksChanged();
            RenderPreviewWatermarks();
        }

        private void ToggleSameIdAlignment_Unchecked(object sender, RoutedEventArgs e)
        {
            if (ToggleSameIdAlignment != null) ToggleSameIdAlignment.Content = "OFF";
            ImageService.IsSameIdAlignmentOn = false;
        }

        private void WMToggleBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_isInitializing || _isUpdatingUI) return;

            var layers = ImageService.GetCurrentPhotoLayers();
            int selectedIndex = MyComboBoxN1.SelectedIndex;
            if (layers == null || selectedIndex == -1 || selectedIndex >= layers.Count) return;

            var activeLayer = layers[selectedIndex];
            bool isChecked = WMToggleBtn.IsChecked ?? false;

            // Оновлюємо UI кнопки
            WMToggleBtn.Content = isChecked ? "ON" : "OFF";
            WMAlignmentComboBox.IsEnabled = isChecked;

            // Зберігаємо в об'єкт шару
            activeLayer.UseAlignment = isChecked;
            if (isChecked)
            {
                activeLayer.AlignmentIndex = WMAlignmentComboBox.SelectedIndex;
            }

            // Якщо знак глобальний — синхронізуємо налаштування по всьому проєкту
            if (activeLayer.IsGlobal)
            {
                SyncGlobalAlignmentSettings(activeLayer);
            }
            else
            {
                // Для локального — просто перераховуємо положення на поточній фотці
                ImageService.ApplyWatermarkAlignment(activeLayer, isDragging: false);
            }

            // Сповіщаємо Canvas на головній формі, щоб перемалювати знак
            ImageService.NotifyWatermarksChanged();

            RenderPreviewWatermarks();
        }
        
        private void SyncGlobalAlignmentSettings(ImageService.WatermarkLayer activeLayer)
        {
            var allPhotos = ImageService.GetAllImageFiles();
            if (allPhotos == null) return;

            foreach (var photoPath in allPhotos)
            {
                if (ImageService.ImageWatermarks.TryGetValue(photoPath, out var targetLayers))
                {
                    // Шукаємо такий самий глобальний знак на інших світлинах
                    var copy = targetLayers.FirstOrDefault(l =>
                        l.Id == activeLayer.Id &&
                        l.IsGlobal &&
                        l.OriginalPhotoPath == activeLayer.OriginalPhotoPath);

                    if (copy != null)
                    {
                        copy.UseAlignment = activeLayer.UseAlignment;
                        copy.AlignmentIndex = activeLayer.AlignmentIndex;

                        // Одразу викликаємо перерахунок координат конкретно під розміри ТІЄЇ фотографії photoPath
                        ImageService.ApplyWatermarkAlignment(copy, isDragging: false, photoPath: photoPath);
                    }
                }
            }
        }

        public void UpdateCoordinateTextBoxes()
        {
            var layers = ImageService.GetCurrentPhotoLayers();
            if (layers == null || MyComboBoxN1.SelectedIndex < 0 || MyComboBoxN1.SelectedIndex >= layers.Count)
                return;

            var layer = layers[MyComboBoxN1.SelectedIndex];

            _isUpdatingUI = true;

            try
            {
                if (WmXBox != null) WmXBox.Text = layer.X.ToString("F0");
                if (WmYBox != null) WmYBox.Text = layer.Y.ToString("F0");

                // === НОВИЙ РЯДОК: Оновлюємо слайдер прозорості під поточний шар ===
                if (WmOpacitySlider != null)
                {
                    WmOpacitySlider.Value = layer.Opacity * 100.0;
                }
                if (WmOpacityLabel != null)
                {
                    WmOpacityLabel.Text = $"{Math.Round(layer.Opacity * 100.0)}%";
                }
            }
            finally
            {
                _isUpdatingUI = false;
            }
        }

        private void WmOpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (_isUpdatingUI || _isInitializing) return;

            if (WmOpacityLabel != null)
            {
                WmOpacityLabel.Text = $"{Math.Round(e.NewValue)}%";
            }

            var layers = ImageService.GetCurrentPhotoLayers();
            if (layers == null || MyComboBoxN1.SelectedIndex < 0 || MyComboBoxN1.SelectedIndex >= layers.Count)
                return;

            var layer = layers[MyComboBoxN1.SelectedIndex];
            double targetOpacity = e.NewValue / 100.0;
            layer.Opacity = targetOpacity; // Зміна для поточного знака

            // Якщо наш переіменований тумблер увімкнено (ON) -> копіюємо далі
            if (ToggleOpacityScope != null && ToggleOpacityScope.IsChecked == true)
            {
                if (ImageService.IsAllWatermarksOpacityMode)
                {
                    ImageService.SyncAllWatermarksOpacity(targetOpacity); // На всі знаки
                }
                else
                {
                    ImageService.SyncWatermarkOpacityById(layer); // Тільки на знаки з таким же ID
                }
            }

            RenderPreviewWatermarks();
        }

        // Кнопка стрілочки "Вліво" (зменшення прозорості на 1%)
        private void OpacityDecrease_Click(object sender, RoutedEventArgs e)
        {
            if (WmOpacitySlider != null)
            {
                WmOpacitySlider.Value = Math.Max(WmOpacitySlider.Minimum, WmOpacitySlider.Value - 1);
            }
        }

        // Кнопка стрілочки "Вправо" (збільшення прозорості на 1%)
        private void OpacityIncrease_Click(object sender, RoutedEventArgs e)
        {
            if (WmOpacitySlider != null)
            {
                WmOpacitySlider.Value = Math.Min(WmOpacitySlider.Maximum, WmOpacitySlider.Value + 1);
            }
        }

        private void UpdateOpacityScopeAvailability()
        {
            if (ComboOpacityScope == null || ToggleOpacityScope == null || ToggleGlobalWatermark == null) return;

            // Режим 1: Якщо обрано "Всіх № водяних знаків" (індекс 1) -> кнопка ЗАВЖДИ активна
            if (ComboOpacityScope.SelectedIndex == 1)
            {
                ToggleOpacityScope.IsEnabled = true;
            }
            // Режим 2: Якщо обрано "Цього № водяного знаку" (індекс 0)
            else
            {
                // Кнопка активна тільки тоді, коли увімкнено ToggleGlobalWatermark
                if (ToggleGlobalWatermark.IsChecked == true)
                {
                    ToggleOpacityScope.IsEnabled = true;
                }
                else
                {
                    // Якщо глобальний перемикач вимкнено — гасимо і скидаємо тумблер прозорості в OFF
                    bool previouslyUpdating = _isUpdatingUI;
                    _isUpdatingUI = true;

                    ToggleOpacityScope.IsChecked = false;
                    ToggleOpacityScope.Content = "OFF";
                    ToggleOpacityScope.IsEnabled = false;

                    _isUpdatingUI = previouslyUpdating;
                }
            }
        }

        private void ComboOpacityScope_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_isUpdatingUI || _isInitializing) return;

            // Зберігаємо вибір у сервіс
            bool isAllMode = (ComboOpacityScope.SelectedIndex == 1);
            ImageService.IsAllWatermarksOpacityMode = isAllMode;

            // Перевіряємо, чи має кнопка згаснути
            UpdateOpacityScopeAvailability();

            // Якщо тумблер увімкнено (ON), миттєво синхронізуємо прозорість по всьому проекту відповідно до режиму
            if (ToggleOpacityScope != null && ToggleOpacityScope.IsChecked == true && WmOpacitySlider != null)
            {
                var layers = ImageService.GetCurrentPhotoLayers();
                if (layers != null && MyComboBoxN1.SelectedIndex >= 0 && MyComboBoxN1.SelectedIndex < layers.Count)
                {
                    var layer = layers[MyComboBoxN1.SelectedIndex];
                    double currentOpacity = WmOpacitySlider.Value / 100.0;

                    if (isAllMode)
                    {
                        ImageService.SyncAllWatermarksOpacity(currentOpacity);
                    }
                    else
                    {
                        ImageService.SyncWatermarkOpacityById(layer);
                    }

                    RenderPreviewWatermarks();
                }
            }
        }

        private void ToggleOpacityScope_Click(object sender, RoutedEventArgs e)
        {
            if (ToggleOpacityScope == null) return;

            bool isChecked = ToggleOpacityScope.IsChecked ?? false;
            ToggleOpacityScope.Content = isChecked ? "ON" : "OFF";

            // Якщо увімкнули тумблер — примусово штовхаємо оновлення повзунка для інших фото
            if (WmOpacitySlider != null)
            {
                var args = new RoutedPropertyChangedEventArgs<double>(WmOpacitySlider.Value, WmOpacitySlider.Value);
                WmOpacitySlider_ValueChanged(WmOpacitySlider, args);
            }
        }

        private void SyncUIWithSelectedWatermark()
        {
            if (_isInitializing) return;

            _isUpdatingUI = true;

            try
            {
                int selectedIndex = MyComboBoxN1.SelectedIndex;
                var currentLayers = ImageService.GetCurrentPhotoLayers();

                if (selectedIndex == -1 || currentLayers == null || selectedIndex >= currentLayers.Count)
                {
                    ToggleGlobalWatermark.IsChecked = false;
                    ToggleGlobalWatermark.Content = "OFF";
                    return;
                }

                var activeLayer = currentLayers[selectedIndex];

                bool isGloballyCopied = false;

                var allPhotos = ImageService.GetAllImageFiles();
                string currentPhotoPath = ImageService.GetCurrentPhotoPath();

                if (allPhotos != null)
                {
                    foreach (var photoPath in allPhotos)
                    {
                        if (photoPath == currentPhotoPath)
                            continue;

                        if (ImageService.ImageWatermarks.TryGetValue(photoPath, out var targetLayers))
                        {
                            if (targetLayers.Any(l =>
                                l.Id == activeLayer.Id &&
                                l.IsGlobal))
                            {
                                isGloballyCopied = true;
                                break;
                            }
                        }
                    }
                }

                ToggleGlobalWatermark.IsChecked = isGloballyCopied;
                ToggleGlobalWatermark.Content = isGloballyCopied ? "ON" : "OFF";
            }
            finally
            {
                _isUpdatingUI = false;
            }
        }
        private void SortAndReorderLayers(List<ImageService.WatermarkLayer> layers)
        {
            if (layers == null || layers.Count <= 1) return;

            // Сортуємо список за вашим правилом
            var sorted = layers
                .OrderBy(x => x.IsGlobal ? 0 : 1)
                .ThenBy(x => x.IsGlobal ? x.GlobalOrder : 0)
                .ThenBy(x => x.Id)
                .ToList();

            layers.Clear();
            layers.AddRange(sorted);
        }
        private int GenerateNextAvailableLocalId(List<ImageService.WatermarkLayer> layers, ImageService.WatermarkLayer currentLayer = null)
        {
            int candidateId = 1;
            if (layers != null)
            {
                // Шукаємо вільний номер, але "не бачимо" знак, який ми зараз клацаємо
                while (layers.Any(l => (l.Id - 1) == candidateId && (currentLayer == null || l != currentLayer)))
                {
                    candidateId++;
                }
            }
            return candidateId;
        }

        private void UpdateWatermarkUIFromSelection()
        {
            var layers = ImageService.GetCurrentPhotoLayers();
            int selectedIndex = MyComboBoxN1.SelectedIndex;

            // Якщо жодного знака не вибрано (наприклад, все видалили), очищаємо UI
            if (layers == null || selectedIndex == -1 || selectedIndex >= layers.Count)
            {
                _isUpdatingUI = true;
                WatermarkPreviewImage.Source = null;
                WMToggleBtn.IsChecked = false;
                WMToggleBtn.Content = "OFF";
                WMAlignmentComboBox.IsEnabled = false;
                WMAlignmentComboBox.SelectedIndex = 0;
                _isUpdatingUI = false;
                return;
            }

            var activeLayer = layers[selectedIndex];

            // 1. Заповнюємо текстові поля розмірів (Ширина / Висота / X / Y)
            LoadCurrentWatermarkToUI();

            // 2. Заповнюємо координати точніше та оновлюємо повзунок прозорості
            UpdateCoordinateTextBoxes();

            // 3. Оновлюємо доступність пов'язаних тумблерів
            UpdateOpacityScopeAvailability();
            UpdateToggleApplyModeAvailability();



            // 4. ОНОВЛЕННЯ КАРТИНКИ ПРЕВ'Ю ДЛЯ ЦЬОГО КОНКРЕТНОГО ЗНАКА
            if (!string.IsNullOrEmpty(activeLayer.ImagePath) && System.IO.File.Exists(activeLayer.ImagePath))
            {
                try
                {
                    WatermarkPreviewImage.Source = new BitmapImage(new Uri(activeLayer.ImagePath, UriKind.RelativeOrAbsolute));
                }
                catch
                {
                    // Захист на випадок проблем із доступом до файлу
                }
            }

            _isUpdatingUI = true; // Захист, щоб зміна значень не викликала івенти кліків випадково
            try
            {
                WMToggleBtn.IsChecked = activeLayer.UseAlignment;
                WMToggleBtn.Content = activeLayer.UseAlignment ? "ON" : "OFF";
                WMAlignmentComboBox.IsEnabled = activeLayer.UseAlignment;
                WMAlignmentComboBox.SelectedIndex = activeLayer.AlignmentIndex;
            }
            finally
            {
                _isUpdatingUI = false;
            }
        }
        // ═══════════════════════════════════════════════════════════════
        //  ПРОФІЛІ ВОДЯНИХ ЗНАКІВ
        // ═══════════════════════════════════════════════════════════════

        private void LoadWatermarkProfiles()
        {
            MyComboBoxN3Watermark.Items.Clear();
            foreach (var p in WatermarkProfileService.Profiles)
                MyComboBoxN3Watermark.Items.Add(p.Name);
        }

        private void ApplyToAllWatermark_Checked(object sender, RoutedEventArgs e)
        {
            ApplyToAllWatermark.Content = "Для всіх полів";
        }

        private void ApplyToAllWatermark_Unchecked(object sender, RoutedEventArgs e)
        {
            ApplyToAllWatermark.Content = "Для цього поля";
        }

        private void SaveProfileWatermark_Click(object sender, RoutedEventArgs e)
        {
            string profileName = MyComboBoxN3Watermark.Text?.Trim() ?? string.Empty;
            if (string.IsNullOrWhiteSpace(profileName))
            {
                MessageBox.Show("Введіть назву профілю");
                return;
            }

            // Знімаємо поточний стан усіх шарів поточного фото
            var layers = ImageService.GetCurrentPhotoLayers();
            var snapshots = layers.Select(l => new WatermarkLayerSnapshot
            {
                ImagePath    = l.ImagePath,
                X            = l.X,
                Y            = l.Y,
                Width        = l.Width,
                Height       = l.Height,
                Opacity      = l.Opacity,
                UseAlignment = l.UseAlignment,
                AlignmentIndex = l.AlignmentIndex
            }).ToList();

            // Перезаписуємо якщо вже існує
            var existing = WatermarkProfileService.Profiles.FirstOrDefault(p => p.Name == profileName);
            if (existing != null) WatermarkProfileService.Profiles.Remove(existing);

            var profile = new WatermarkProfile
            {
                Name       = profileName,
                ApplyToAll = ApplyToAllWatermark.IsChecked == true,
                Layers     = snapshots
            };
            WatermarkProfileService.Profiles.Add(profile);
            WatermarkProfileService.Save();

            // Запам'ятовуємо для поточного фото
            string currentPath = ImageService.GetCurrentPhotoPath();
            if (!string.IsNullOrEmpty(currentPath))
                _wmPhotoProfiles[currentPath] = profileName;

            LoadWatermarkProfiles();

            _isUpdatingUI = true;
            MyComboBoxN3Watermark.SelectedItem = profileName;
            if (MyComboBoxN3Watermark.SelectedIndex < 0)
                MyComboBoxN3Watermark.Text = profileName;
            _isUpdatingUI = false;
        }

        private void MyComboBoxN3Watermark_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_isUpdatingUI) return;
            if (MyComboBoxN3Watermark.SelectedItem == null) return;

            string selected = MyComboBoxN3Watermark.SelectedItem.ToString() ?? string.Empty;
            var profile = WatermarkProfileService.Profiles.FirstOrDefault(p => p.Name == selected);
            if (profile == null) return;

            if (ApplyToAllWatermark.IsChecked == true)
            {
                // Застосовуємо до всіх фото
                foreach (var path in ImageService.GetAllImageFiles())
                    _wmPhotoProfiles[path] = selected;
            }
            else
            {
                string photoPath = ImageService.GetCurrentPhotoPath();
                if (!string.IsNullOrEmpty(photoPath))
                    _wmPhotoProfiles[photoPath] = selected;
            }

            ApplyToAllWatermark.IsChecked = profile.ApplyToAll;
            ApplyWatermarkProfileByName(selected);
        }

        private void DeleteProfileWatermark_Click(object sender, RoutedEventArgs e)
        {
            if (MyComboBoxN3Watermark.SelectedItem == null) return;

            string selected = MyComboBoxN3Watermark.SelectedItem.ToString() ?? string.Empty;
            var profile = WatermarkProfileService.Profiles.FirstOrDefault(p => p.Name == selected);
            if (profile == null) return;

            WatermarkProfileService.Profiles.Remove(profile);
            WatermarkProfileService.Save();

            // Знімаємо прив'язку з усіх фото
            var toRemove = _wmPhotoProfiles.Where(kv => kv.Value == selected).Select(kv => kv.Key).ToList();
            foreach (var key in toRemove) _wmPhotoProfiles.Remove(key);

            LoadWatermarkProfiles();
            MyComboBoxN3Watermark.SelectedIndex = -1;
            MyComboBoxN3Watermark.Text = string.Empty;
        }

        /// <summary>
        /// Замінює всі поточні шари фото на шари з профілю.
        /// Глобальні знаки не торкаємось — профіль стосується лише локальних.
        /// </summary>
        private void ApplyWatermarkProfileByName(string profileName)
        {
            var profile = WatermarkProfileService.Profiles.FirstOrDefault(p => p.Name == profileName);
            if (profile == null) return;

            string currentPath = ImageService.GetCurrentPhotoPath();
            if (string.IsNullOrEmpty(currentPath)) return;

            // Залишаємо глобальні знаки, видаляємо локальні
            var layers = ImageService.GetCurrentPhotoLayers();
            layers.RemoveAll(l => !l.IsGlobal);

            // Відновлюємо локальні шари з профілю
            int nextId = 1;
            foreach (var snap in profile.Layers)
            {
                // Генеруємо унікальний локальний ID
                while (layers.Any(l => l.Id == nextId)) nextId++;

                var layer = new WatermarkLayer
                {
                    Id             = nextId++,
                    ImagePath      = snap.ImagePath,
                    X              = snap.X,
                    Y              = snap.Y,
                    Width          = snap.Width,
                    Height         = snap.Height,
                    Opacity        = snap.Opacity,
                    UseAlignment   = snap.UseAlignment,
                    AlignmentIndex = snap.AlignmentIndex,
                    IsGlobal       = false,
                    OriginalPhotoPath = currentPath
                };
                layers.Add(layer);
                ImageService.ApplyWatermarkAlignment(layer, isDragging: false);
            }

            ImageService.NotifyWatermarksChanged();
            RefreshWatermarkComboBox();
            RenderPreviewWatermarks();
        }

                private void streams_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (streams.SelectedItem != null)
            {
                int threadCount = Convert.ToInt32(streams.SelectedItem);

                Properties.Settings.Default.ThreadCount = threadCount;
                Properties.Settings.Default.Save();
            }
        }

        private void RedactorName_TextChanged(
    object sender,
    TextChangedEventArgs e)
        {
            Properties.Settings.Default.RedactorName = RedactorName.Text;

            Properties.Settings.Default.Save();
        }

    }
}
