﻿using ImageProcessing.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ImageProcessing
{
    /// <summary>
    /// Логика взаимодействия для Login.xaml
    /// </summary>
    public partial class Login : Page
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            var user = AuthService.Login(
                LoginBox.Text,
                PasswordBox.Password);

            if (user == null)
            {
                MessageBox.Show("Невірний логін або пароль");
                return;
            }

            AuthService.CurrentUser = user;

            

            MainWindow mainWindow = (MainWindow)Application.Current.MainWindow;

            mainWindow._settingsPage.UpdatePermissions();

            mainWindow.MainFrame.Navigate(
                mainWindow._redactorPage);

        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            bool success = AuthService.Register(
                LoginBox.Text,
                PasswordBox.Password);

            if (!success)
            {
                MessageBox.Show("Користувач уже існує");
                return;
            }

            MessageBox.Show("Реєстрація успішна");
        }
    }
}
